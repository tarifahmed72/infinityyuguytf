

const BankAgent = () => {
  return (
    <div>BankAgent</div>
  )
}

export default BankAgent